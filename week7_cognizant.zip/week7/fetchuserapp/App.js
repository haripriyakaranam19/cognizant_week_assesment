
import React from 'react';
import Getuser from './Getuser';

function App() {
  return (
    <div className="App">
      <h1>Random User Generator</h1>
      <Getuser />
    </div>
  );
}

export default App;
