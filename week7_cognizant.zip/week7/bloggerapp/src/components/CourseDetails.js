import React from 'react';

function CourseDetails() {
  return <h2>This is Course Details</h2>;
}

export default CourseDetails;
