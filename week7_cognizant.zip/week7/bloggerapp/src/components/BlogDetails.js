import React from 'react';

function BlogDetails() {
  return <h2>This is Blog Details</h2>;
}

export default BlogDetails;
