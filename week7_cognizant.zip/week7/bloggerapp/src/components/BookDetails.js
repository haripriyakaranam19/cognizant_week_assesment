import React from 'react';

function BookDetails() {
  return <h2>This is Book Details</h2>;
}

export default BookDetails;
