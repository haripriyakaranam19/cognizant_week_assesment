
import React from 'react';
import Register from './register';

function App() {
  return (
    <div className="App">
      <h1>Registration Form</h1>
      <Register />
    </div>
  );
}

export default App;
